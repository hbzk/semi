Free Vector Infographic Design Template (AI)

URL: http://sixrevisions.com/freebies/free-vector-infographic-design-template

You MAY use the source files in this package for commercial
purposes.

You MAY NOT redistribute or sell the source files in this package.

Six Revisions (sixrevisions.com)

Author     Freepik.com
Copyright  Freepik.com