#License

You are free to use this kit as you like provided you *do not* redistribute it - either commercially or as a 'freebie' - or host it on your own website or server or claim credit for it.

Made by [@adamwhitcroft](https://twitter.com/adamwhitcroft).