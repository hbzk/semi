#[WireKit](http://adamwhitcroft.com/wirekit)

A bunch of Photoshop shape layers to make wireframing your next iPhone app just a little easier, by [@adamwhitcroft](https://twitter.com/adamwhitcroft).

840 x 8600 pixels of retina-friendly-made-to-measure-scalable goodness presented in two unique styles, each with over 60 of the most common UI elements.

##Versions

As this resource may well expand, it made the most sense to host it on GitHub for the versioning, wiki and issues features.
